// app.js
App({
  data:{
    //baseUrl:"https://yzb.propranolol.cn/frontpage"
    //baseUrl:"http://eat.emmmmm.tk/frontpage"
    baseUrl:"https://yuming.propranolol.cn/frontpage"
  },
  onLaunch() {
    
  },
  globalData: {
    token:"",
    
  }
})
